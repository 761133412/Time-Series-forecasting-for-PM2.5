import time
from keras.callbacks import Callback
from keras.models import Input, Model, Sequential                     #### TCN
from keras.layers import Dense, Activation, Conv1D, LSTM, Dropout, Reshape, Bidirectional, Flatten, Add, Concatenate, MaxPool1D, LeakyReLU, GRU
import keras.backend as K

from _Support.support_NLSTM import NestedLSTM


class TimeHistory(Callback):
	def on_train_begin(self, logs={}):
		self.times = []
		self.totaltime = time.time()
	
	def on_train_end(self, logs={}):
		self.totaltime = time.time() - self.totaltime
	
	def on_epoch_begin(self, batch, logs={}):
		self.epoch_time_start = time.time()
	
	def on_epoch_end(self, batch, logs={}):
		self.times.append(time.time() - self.epoch_time_start)


def build_GRU(timestep):
	
	batch_size, timesteps, input_dim = None, timestep, 1
	i = Input(batch_shape=(batch_size, timesteps, input_dim))
	
	x = GRU(64)(i)
	x = Dense(16, activation='linear')(x)
	o = Dense(1, activation="linear")(x)
	
	model = Model(inputs=[i], outputs=[o])
	model.compile(optimizer='rmsprop', loss='mse', )
	model.summary()
	
	return model


def build_LSTM(timestep):
	
	batch_size, timesteps, input_dim = None, timestep, 1
	i = Input(batch_shape=(batch_size, timesteps, input_dim))
	
	x = LSTM(64)(i)
	x = Dense(16, activation='linear')(x)
	o = Dense(1, activation="linear")(x)
	
	model = Model(inputs=[i], outputs=[o])
	model.compile(optimizer='rmsprop', loss='mse', )
	model.summary()
	
	return model


def build_SLSTM(timestep):
	batch_size, timesteps, input_dim = None, timestep, 1
	i = Input(batch_shape=(batch_size, timesteps, input_dim))
	
	x = Reshape((-1, 1))(i)
	x = LSTM(64, return_sequences=True)(x)
	x = LSTM(64, return_sequences=True)(x)
	x = LSTM(64)(x)
	x = Dense(16, activation='linear')(x)
	o = Dense(1, activation="linear")(x)
	
	model = Model(inputs=[i], outputs=[o])
	
	model.compile(optimizer='rmsprop', loss='mse', )
	model.summary()
	return model


def build_BiLSTM(timestep):
	
	batch_size, timesteps, input_dim = None, timestep, 1
	i = Input(batch_shape=(batch_size, timesteps, input_dim))
	
	x = Bidirectional(LSTM(64), merge_mode='concat')(i)
	x = Dense(16, activation='linear')(x)
	o = Dense(1, activation="linear")(x)
	
	model = Model(inputs=[i], outputs=[o])
	
	model.compile(optimizer='Adam', loss='mse', )
	model.summary()
	
	return model


def build_NLSTM(timestep):
	
	batch_size, timesteps, input_dim = None, timestep, 1
	i = Input(batch_shape=(batch_size, timesteps, input_dim))
	
	x = NestedLSTM(64, depth=2, dropout=0.0, recurrent_dropout=0.1)(i)
	x = Dense(16, activation='linear')(x)
	o = Dense(1, activation="linear")(x)
	
	model = Model(inputs=[i], outputs=[o])
	model.compile(optimizer='rmsprop', loss='mse', )
	model.summary()
	
	return model


def buildNLSTM_MV(timestep):
	batch_size, timesteps, input_dim = None, timestep, 1
	
	input_0 = Input(batch_shape=(batch_size, timesteps, input_dim))
	x0 = NestedLSTM(64, depth=2, dropout=0.0, recurrent_dropout=0.1)(input_0)
	x0 = Dense(16, activation='linear')(x0)
	model0 = Model(inputs=input_0, outputs=x0)
	
	input_1 = Input(batch_shape=(batch_size, timesteps, input_dim))
	x1 = NestedLSTM(64, depth=2, dropout=0.0, recurrent_dropout=0.1)(input_1)
	x1 = Dense(16, activation='linear')(x1)
	model1 = Model(inputs=input_1, outputs=x1)
	
	input_2 = Input(batch_shape=(batch_size, timesteps, input_dim))
	x2 = NestedLSTM(64, depth=2, dropout=0.0, recurrent_dropout=0.1)(input_2)
	x2 = Dense(16, activation='linear')(x2)
	model2 = Model(inputs=input_2, outputs=x2)
	
	input_3 = Input(batch_shape=(batch_size, timesteps, input_dim))
	x3 = NestedLSTM(64, depth=2, dropout=0.0, recurrent_dropout=0.1)(input_3)
	x3 = Dense(16, activation='linear')(x3)
	model3 = Model(inputs=input_3, outputs=x3)
	
	input_4 = Input(batch_shape=(batch_size, timesteps, input_dim))
	x4 = NestedLSTM(64, depth=2, dropout=0.0, recurrent_dropout=0.1)(input_4)
	x4 = Dense(16, activation='linear')(x4)
	model4 = Model(inputs=input_4, outputs=x4)
	
	input_5 = Input(batch_shape=(batch_size, timesteps, input_dim))
	x5 = NestedLSTM(64, depth=2, dropout=0.0, recurrent_dropout=0.1)(input_5)
	x5 = Dense(16, activation='linear')(x5)
	model5 = Model(inputs=input_5, outputs=x5)
	
	combined = Concatenate(axis=1)([model0.output,
	                                model1.output,
	                                model2.output,
	                                model3.output,
	                                model4.output,
	                                model5.output])
	
	output0 = Dense(1, activation='linear')(combined)
	
	output1 = Dense(1, activation='linear')(combined)
	
	output2 = Dense(1, activation='linear')(combined)
	
	output3 = Dense(1, activation='linear')(combined)
	
	output4 = Dense(1, activation='linear')(combined)
	
	output5 = Dense(1, activation='linear')(combined)
	
	model = Model(inputs=[model0.input,
	                      model1.input,
	                      model2.input,
	                      model3.input,
	                      model4.input,
	                      model5.input],
	              outputs=[output0,
	                       output1,
	                       output2,
	                       output3,
	                       output4,
	                       output5]
	              )
	
	model.compile(optimizer='rmsprop', loss='mse', )
	model.summary()
	
	return model


def buildNLSTM_MTMC(timestep):
	batch_size, timesteps, input_dim = None, timestep, 1
	
	##############################################################################################
	
	input_0A3 = Input(batch_shape=(batch_size, timesteps, input_dim))
	x00 = NestedLSTM(48, depth=2, dropout=0.0, recurrent_dropout=0.1)(input_0A3)
	x00 = Dense(16, activation='linear')(x00)
	
	input_0D1 = Input(batch_shape=(batch_size, timesteps, input_dim))
	x01 = NestedLSTM(32, depth=2, dropout=0.0, recurrent_dropout=0.1)(input_0D1)
	x01 = Dense(16, activation='linear')(x01)
	
	input_0D2 = Input(batch_shape=(batch_size, timesteps, input_dim))
	x02 = NestedLSTM(24, depth=2, dropout=0.0, recurrent_dropout=0.1)(input_0D2)
	x02 = Dense(16, activation='linear')(x02)
	
	input_0D3 = Input(batch_shape=(batch_size, timesteps, input_dim))
	x03 = NestedLSTM(24, depth=2, dropout=0.0, recurrent_dropout=0.1)(input_0D3)
	x03 = Dense(16, activation='linear')(x03)
	
	combined0 = Add()([x00, x01, x02, x03])
	o0 = combined0
	# o0 = Dense(1, activation="linear")(combined0)
	
	model0 = Model(inputs=[input_0A3, input_0D1, input_0D2, input_0D3], outputs=o0)
	
	##############################################################################################
	
	input_1A3 = Input(batch_shape=(batch_size, timesteps, input_dim))
	x10 = NestedLSTM(48, depth=2, dropout=0.0, recurrent_dropout=0.1)(input_1A3)
	x10 = Dense(16, activation='linear')(x10)
	
	input_1D1 = Input(batch_shape=(batch_size, timesteps, input_dim))
	x11 = NestedLSTM(32, depth=2, dropout=0.0, recurrent_dropout=0.1)(input_1D1)
	x11 = Dense(16, activation='linear')(x11)
	
	input_1D2 = Input(batch_shape=(batch_size, timesteps, input_dim))
	x12 = NestedLSTM(24, depth=2, dropout=0.0, recurrent_dropout=0.1)(input_1D2)
	x12 = Dense(16, activation='linear')(x12)
	
	input_1D3 = Input(batch_shape=(batch_size, timesteps, input_dim))
	x13 = NestedLSTM(24, depth=2, dropout=0.0, recurrent_dropout=0.1)(input_1D3)
	x13 = Dense(16, activation='linear')(x13)
	
	combined1 = Add()([x10, x11, x12, x13])
	o1 = combined1
	# o1 = Dense(1, activation="linear")(combined1)
	
	model1 = Model(inputs=[input_1A3, input_1D1, input_1D2, input_1D3], outputs=o1)
	
	##############################################################################################
	
	input_2A3 = Input(batch_shape=(batch_size, timesteps, input_dim))
	x20 = NestedLSTM(48, depth=2, dropout=0.0, recurrent_dropout=0.1)(input_2A3)
	x20 = Dense(16, activation='linear')(x20)
	
	input_2D1 = Input(batch_shape=(batch_size, timesteps, input_dim))
	x21 = NestedLSTM(32, depth=2, dropout=0.0, recurrent_dropout=0.1)(input_2D1)
	x21 = Dense(16, activation='linear')(x21)
	
	input_2D2 = Input(batch_shape=(batch_size, timesteps, input_dim))
	x22 = NestedLSTM(24, depth=2, dropout=0.0, recurrent_dropout=0.1)(input_2D2)
	x22 = Dense(16, activation='linear')(x22)
	
	input_2D3 = Input(batch_shape=(batch_size, timesteps, input_dim))
	x23 = NestedLSTM(24, depth=2, dropout=0.0, recurrent_dropout=0.1)(input_2D3)
	x23 = Dense(16, activation='linear')(x23)
	
	combined2 = Add()([x20, x21, x22, x23])
	o2 = combined2
	# o2 = Dense(1, activation="linear")(combined2)
	
	model2 = Model(inputs=[input_2A3, input_2D1, input_2D2, input_2D3], outputs=o2)
	
	##############################################################################################
	
	input_3A3 = Input(batch_shape=(batch_size, timesteps, input_dim))
	x30 = NestedLSTM(48, depth=2, dropout=0.0, recurrent_dropout=0.1)(input_3A3)
	x30 = Dense(16, activation='linear')(x30)
	
	input_3D1 = Input(batch_shape=(batch_size, timesteps, input_dim))
	x31 = NestedLSTM(32, depth=2, dropout=0.0, recurrent_dropout=0.1)(input_3D1)
	x31 = Dense(16, activation='linear')(x31)
	
	input_3D2 = Input(batch_shape=(batch_size, timesteps, input_dim))
	x32 = NestedLSTM(24, depth=2, dropout=0.0, recurrent_dropout=0.1)(input_3D2)
	x32 = Dense(16, activation='linear')(x32)
	
	input_3D3 = Input(batch_shape=(batch_size, timesteps, input_dim))
	x33 = NestedLSTM(24, depth=2, dropout=0.0, recurrent_dropout=0.1)(input_3D3)
	x33 = Dense(16, activation='linear')(x33)
	
	combined3 = Add()([x30, x31, x32, x33])
	o3 = combined3
	# o3 = Dense(1, activation="linear")(combined3)
	
	model3 = Model(inputs=[input_3A3, input_3D1, input_3D2, input_3D3], outputs=o3)
	
	##############################################################################################
	
	input_4A3 = Input(batch_shape=(batch_size, timesteps, input_dim))
	x40 = NestedLSTM(48, depth=2, dropout=0.0, recurrent_dropout=0.1)(input_4A3)
	x40 = Dense(16, activation='linear')(x40)
	
	input_4D1 = Input(batch_shape=(batch_size, timesteps, input_dim))
	x41 = NestedLSTM(32, depth=2, dropout=0.0, recurrent_dropout=0.1)(input_4D1)
	x41 = Dense(16, activation='linear')(x41)
	
	input_4D2 = Input(batch_shape=(batch_size, timesteps, input_dim))
	x42 = NestedLSTM(24, depth=2, dropout=0.0, recurrent_dropout=0.1)(input_4D2)
	x42 = Dense(16, activation='linear')(x42)
	
	input_4D3 = Input(batch_shape=(batch_size, timesteps, input_dim))
	x43 = NestedLSTM(24, depth=2, dropout=0.0, recurrent_dropout=0.1)(input_4D3)
	x43 = Dense(16, activation='linear')(x43)
	
	combined4 = Add()([x40, x41, x42, x43])
	o4 = combined4
	# o4 = Dense(1, activation="linear")(combined4)
	
	model4 = Model(inputs=[input_4A3, input_4D1, input_4D2, input_4D3], outputs=o4)
	
	##############################################################################################
	
	input_5A3 = Input(batch_shape=(batch_size, timesteps, input_dim))
	x50 = NestedLSTM(48, depth=2, dropout=0.0, recurrent_dropout=0.1)(input_5A3)
	x50 = Dense(16, activation='linear')(x50)
	
	input_5D1 = Input(batch_shape=(batch_size, timesteps, input_dim))
	x51 = NestedLSTM(32, depth=2, dropout=0.0, recurrent_dropout=0.1)(input_5D1)
	x51 = Dense(16, activation='linear')(x51)
	
	input_5D2 = Input(batch_shape=(batch_size, timesteps, input_dim))
	x52 = NestedLSTM(24, depth=2, dropout=0.0, recurrent_dropout=0.1)(input_5D2)
	x52 = Dense(16, activation='linear')(x52)
	
	input_5D3 = Input(batch_shape=(batch_size, timesteps, input_dim))
	x53 = NestedLSTM(24, depth=2, dropout=0.0, recurrent_dropout=0.1)(input_5D3)
	x53 = Dense(16, activation='linear')(x53)
	
	combined5 = Add()([x50, x51, x52, x53])
	o5 = combined5
	# o4 = Dense(1, activation="linear")(combined4)
	
	model5 = Model(inputs=[input_5A3, input_5D1, input_5D2, input_5D3], outputs=o5)
	
	##############################################################################################
	
	combined = Concatenate(axis=1)([o0, o1, o2, o3, o4, o5])
	
	Output0 = Dense(1, activation='linear')(combined)
	
	Output1 = Dense(1, activation='linear')(combined)
	
	Output2 = Dense(1, activation='linear')(combined)
	
	Output3 = Dense(1, activation='linear')(combined)
	
	Output4 = Dense(1, activation='linear')(combined)
	
	Output5 = Dense(1, activation='linear')(combined)
	
	model = Model(inputs=[input_0A3, input_0D1, input_0D2, input_0D3,
	                      input_1A3, input_1D1, input_1D2, input_1D3,
	                      input_2A3, input_2D1, input_2D2, input_2D3,
	                      input_3A3, input_3D1, input_3D2, input_3D3,
	                      input_4A3, input_4D1, input_4D2, input_4D3,
	                      input_5A3, input_5D1, input_5D2, input_5D3],
	              outputs=[Output0,
	                       Output1,
	                       Output2,
	                       Output3,
	                       Output4,
	                       Output5])
	
	model.compile(optimizer='rmsprop', loss='mse', )
	model.summary()
	
	return model